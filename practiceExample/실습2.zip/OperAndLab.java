
public class OperAndLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int grade = (int)(Math.random()*6)+1;
		if(grade ==1 && grade >0)
			System.out.println(grade+" 학년은 저학년입니다.");
		else if(grade ==2 && grade>0)
			System.out.println(grade+" 학년은 저학년입니다.");
		else if(grade ==3 && grade>0)
			System.out.println(grade+" 학년은 저학년입니다.");
		else
			System.out.println(grade+" 학년은 고학년입니다.");
	}

}
