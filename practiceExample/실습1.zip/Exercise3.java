
public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char name1 = '안';
		char name2 = '인';
		char name3 = '균';
		System.out.print(name1);
		System.out.print(name2);
		System.out.print(name3);
	}

}
