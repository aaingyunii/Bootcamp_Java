
public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 35;
		int y = 10;
		
		System.out.println(x+" 를 "+y+" 으로 나눈 결과 몫은 "+(35/10)+
				" 이고 나머지는 "+(x%y)+" 입니다.");
	}
	
}
