
public class Exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int b = 25;
		int c = 33;
		
		System.out.println("합계 : "+(a+b+c));
		System.out.println("평균 : "+(a+b+c)/3);
	}

}
